# nxs-chat-redmine - plugin for Redmine
# Copyright (C) 2006-2014  Jean-Philippe Lang
# Copyright (C) 2017  Nixys Ltd.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

require 'net/http'
require 'uri'
require 'open-uri'
require 'json'

module ChatHelper
  def self.included(base) # :nodoc:
    base.send(:include, InstanceModules)
  end

  module InstanceModules
    module Chat

      def self.get_recipients_for_notification(issue, editing_user = nil)
        recipients = []
        
        # Добавить автора задачи
        recipients << issue.author if issue.author
        # Добавить пользователя, на которого назначена задача
        recipients << issue.assigned_to if issue.assigned_to
        # Добавить наблюдателей задачи
        recipients.concat(issue.watcher_users) if issue.watcher_users
        # Удалить дубликаты
        recipients.uniq!
        # Удаляем пользователя, который сделал изменение
        recipients.delete(editing_user) if editing_user

        recipients.map do |user|
          custom_value = user.custom_value_for(76) # получаем username telegramm
          telegram_username = custom_value ? custom_value.value : nil
          { id: user.id, name: telegram_username || user.name }
        end
      end

      # Return hash with data from issue and journals (optional) objects
      #
      # Based on template from redmine/app/views/issues/show.api.rsb
      def self.issue_as_json(issue: nil, journals: nil)
        json = {}

        # ID задачи
        json[:id] = issue.id

        # Проект
        json[:project] = {:id => issue.project_id, :name => issue.project.name} unless issue.project.nil?

        # Имя задачи
        json[:subject] = issue.subject

        # Измененные поля и комментарии
        json[:changes] = []
        unless journals.nil?
          journals.compact.each do |journal|
            change = {}
            change[:user] = {:id => journal.user_id, :name => journal.user.name} unless journal.user.nil?
            change[:notes] = journal.notes unless journal.notes.blank?
            change[:details] = []
            journal.visible_details.each do |detail|
              change_detail = {
                :property => detail.property,
                :name => detail.prop_key,
                :old_value => detail.old_value,
                :new_value => detail.value
              }

              # Проверить тип изменения и получить соответствующие значения
              case detail.prop_key
              when 'status_id'
                change_detail[:old_value] = IssueStatus.find_by(id: detail.old_value).try(:name)
                change_detail[:new_value] = IssueStatus.find_by(id: detail.value).try(:name)
              when 'assigned_to_id'
                change_detail[:old_value] = User.find_by(id: detail.old_value).try(:name)
                change_detail[:new_value] = User.find_by(id: detail.value).try(:name)
              when 'tracker_id'
                change_detail[:old_value] = Tracker.find_by(id: detail.old_value).try(:name)
                change_detail[:new_value] = Tracker.find_by(id: detail.value).try(:name)
              end
              change[:details] += [change_detail]
            end
            json[:changes] += [change] unless change[:details].empty? && change[:notes].nil?
          end
        end

        json
      end

      # Send event info to external web server (webhook)
      def self.send_event(action: nil, data: nil)
        begin
          uri = URI.parse(Setting.plugin_nxs_chat['notifications_endpoint'])
        rescue => e
          logger.error "Parsing URI for notifications failed:\n"\
                       "  Exception: #{e.message}" if logger
          return
        end

        unless uri.kind_of?(URI::HTTP) or uri.kind_of?(URI::HTTPS)
          logger.error "Parsing URI for notifications failed" if logger
          return
        end

        # Prepare the data
        header = {
          'Content-Type' => 'text/json'
        }
        json_data = JSON.generate({ :action => action, :data => data })

        # Create the HTTP objects
        http = Net::HTTP.new(uri.host, uri.port)
        if uri.scheme == 'https'
          http.use_ssl = true
          http.verify_mode = OpenSSL::SSL::VERIFY_NONE if Setting.plugin_nxs_chat['notifications_endpoint_ssl_verify_none']
        end
        request = Net::HTTP::Post.new(uri.request_uri, header)
        request.body = json_data

        # Send the request
        begin
          response = http.request(request)
        rescue => e
          logger.error "Sending notification failed:\n"\
                       "  URI: #{uri}\n"\
                       "  Exception: #{e.message}" if logger
          return
        end

        unless response.code.to_i == 200
          logger.error "Sending notification failed:\n"\
                       "  URI: #{uri}\n"\
                       "  Response code: #{response.code}" if logger
          return
        else
          logger.info "Notification has been sent successfully:\n"\
                      "  URI: #{uri}\n"\
                      "  Response code: #{response.code}" if logger
        end
      end

      def self.logger
        Rails.logger
      end
    end
  end
end

Redmine::Helpers.send(:include, ChatHelper)
